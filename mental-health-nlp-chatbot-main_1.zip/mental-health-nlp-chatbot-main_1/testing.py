import json
from collections import Counter

# Load the dataset
with open('augmented_intents_01.json', 'r') as f:
    intents = json.load(f)

# Count patterns per tag
pattern_counts = {intent['tag']: len(intent['patterns']) for intent in intents['intents']}

county = 1
# Display tags with less than 50 patterns
for tag, count in pattern_counts.items():
    print(f"{county} -Tag: {tag}, Patterns: {count}")   
    county+=1

# import random
# from nltk.corpus import wordnet
# import nltk

# nltk.download('wordnet')
# nltk.download('omw-1.4')

# def replace_synonyms(sentence, num_replacements=1):
#     """
#     Replace words in a sentence with their synonyms.
#     :param sentence: Input sentence (string)
#     :param num_replacements: Number of words to replace with synonyms.
#     :return: Augmented sentence (string)
#     """
#     words = sentence.split()
#     new_sentence = words[:]
#     for _ in range(num_replacements):
#         word_to_replace = random.choice(words)
#         synonyms = wordnet.synsets(word_to_replace)
#         # Get the lemmas for the first synonym
#         lemmas = [lemma.name() for syn in synonyms for lemma in syn.lemmas()]
#         lemmas = list(set(lemmas))  # Remove duplicates
#         lemmas = [lemma for lemma in lemmas if lemma != word_to_replace]  # Avoid replacing with the same word
        
#         if lemmas:
#             synonym = random.choice(lemmas)
#             # Replace the word with a synonym
#             new_sentence = [synonym if word == word_to_replace else word for word in new_sentence]
#     return " ".join(new_sentence)

# import json

# def augment_dataset(intents, num_augments=3):
#     """
#     Augment patterns in each intent using synonym replacement.
#     :param intents: Dictionary of intents (loaded from JSON).
#     :param num_augments: Number of augmented sentences per pattern.
#     :return: Augmented dataset (dictionary).
#     """
#     augmented_intents = {"intents": []}

#     for intent in intents["intents"]:
#         augmented_patterns = intent["patterns"][:]
#         for pattern in intent["patterns"]:
#             for _ in range(num_augments):
#                 augmented_patterns.append(replace_synonyms(pattern))
        
#         augmented_intents["intents"].append({
#             "tag": intent["tag"],
#             "patterns": list(set(augmented_patterns)),  # Remove duplicates
#             "responses": intent["responses"]
#         })
    
#     return augmented_intents

# # Load your dataset
# with open("updated_augmented_intents.json", "r") as f:
#     intents = json.load(f)

# # Augment the dataset
# augmented_intents = augment_dataset(intents)

# # Save the augmented dataset
# with open("augmented_intents_01.json", "w") as f:
#     json.dump(augmented_intents, f, indent=4)
