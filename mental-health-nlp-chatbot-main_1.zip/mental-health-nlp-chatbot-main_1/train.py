import numpy as np
import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import precision_recall_fscore_support
from nltk_utils import tokenize, bag_of_words
from model import NeuralNet, ChatDataset

# Load intents file
with open("augmented_intents_01.json", "r") as f:
    intents = json.load(f)

# Prepare data
all_words = []
tags = []
xy = []

for intent in intents["intents"]:
    tag = intent["tag"]
    tags.append(tag)
    for pattern in intent["patterns"]:
        w = tokenize(pattern)
        all_words.extend(w)
        xy.append((w, tag))

# Remove special characters and duplicates
ignore_words = ["?", "!", ".", ","]
all_words = sorted(set(word for word in all_words if word not in ignore_words))
tags = sorted(set(tags))

# Create training data
X_train = []
y_train = []

for (pattern_sentence, tag) in xy:
    bag = bag_of_words(pattern_sentence, all_words)
    X_train.append(bag)
    label = tags.index(tag)
    y_train.append(label)

X_train = np.array(X_train)
y_train = np.array(y_train)

# Create dataset and DataLoader
dataset = ChatDataset(X_train, y_train)
batch_size = 8
data_loader = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=True)

# Hyperparameters
config = {
    "input_size": len(X_train[0]),
    "hidden_size": 128,
    "num_classes": len(tags),
    "learning_rate": 0.001,
    "num_epochs": 500,
    "dropout_rate": 0.5,
}

# Initialize model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = NeuralNet(
    config["input_size"], config["hidden_size"], config["num_classes"], config["dropout_rate"]
).to(device)

# Loss and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"], weight_decay=1e-5)

# Learning rate scheduler
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, mode="min", factor=0.5, patience=5, verbose=True
)

# Training loop
best_val_loss = float("inf")
best_epoch = 0

print("Training started...\n")
for epoch in range(config["num_epochs"]):
    model.train()
    running_loss = 0
    correct_predictions = 0
    total_predictions = 0
    all_preds = []
    all_labels = []

    for words, labels in data_loader:
        words, labels = words.to(device), labels.to(device).long()

        # Forward pass
        outputs = model(words)
        loss = criterion(outputs, labels)

        # Backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Metrics
        _, predicted = torch.max(outputs, dim=1)
        correct_predictions += (predicted == labels).sum().item()
        total_predictions += labels.size(0)
        running_loss += loss.item()
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

    # Calculate metrics for this epoch
    train_loss = running_loss / total_predictions
    train_accuracy = 100 * correct_predictions / total_predictions

    # Calculate Precision, Recall, and F1 Score
    train_precision, train_recall, train_f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average="weighted", zero_division=0
    )

    # Scheduler step based on training loss
    scheduler.step(train_loss)

    # Logging
    print(
        f"Epoch [{epoch+1}/{config['num_epochs']}], "
        f"Loss: {train_loss:.4f}, Accuracy: {train_accuracy:.2f}%, "
        f"Precision: {train_precision:.2f}, Recall: {train_recall:.2f}, F1: {train_f1:.2f}"
    )

    # Save the best model
    if train_loss < best_val_loss:
        best_val_loss = train_loss
        best_epoch = epoch
        torch.save(model.state_dict(), "best_model.pth")

# Load the best model
model.load_state_dict(torch.load("best_model.pth"))

# Save model metadata
metadata = {
    "input_size": config["input_size"],
    "hidden_size": config["hidden_size"],
    "output_size": config["num_classes"],
    "all_words": all_words,
    "tags": tags,
    "model_state": model.state_dict(),
}
torch.save(metadata, "data.pth")

print("\nTraining complete!")
print(f"Best model saved from epoch {best_epoch+1} with loss: {best_val_loss:.4f}")
