import json
import numpy as np
import torch
import random
from model import NeuralNet
from nltk_utils import tokenize, bag_of_words
from fuzzywuzzy import fuzz

# Download NLTK data if needed
import nltk
nltk.download('punkt')

# Initialize stemmer
from nltk.stem.porter import PorterStemmer
stemmer = PorterStemmer()

# Function for fuzzy matching
def fuzzy_match(word, all_words, threshold=80):
    for vocab_word in all_words:
        similarity = fuzz.ratio(word.lower(), vocab_word.lower())
        if similarity >= threshold:
            return vocab_word
    return word  # Return the word if no close match is found

# Load the trained model from file
def load_model():
    FILE = "data.pth"
    data = torch.load(FILE)
    
    input_size = data["input_size"]
    hidden_size = data["hidden_size"]
    output_size = data["output_size"]
    all_words = data["all_words"]
    tags = data["tags"]
    model_state = data["model_state"]

    model = NeuralNet(input_size, hidden_size, output_size)
    model.load_state_dict(model_state)
    model.eval()  # Set the model to evaluation mode

    return model, all_words, tags

# Get the chatbot response based on user input
def get_response(sentence, model, all_words, tags):
    # Tokenize the sentence
    sentence_tokens = tokenize(sentence)

    # Use fuzzy matching for each token in the sentence
    sentence_tokens = [fuzzy_match(word, all_words) for word in sentence_tokens]
    
    # Create bag of words based on the fuzzy-matched tokens
    X = bag_of_words(sentence_tokens, all_words)
    X = X.reshape(1, X.shape[0])
    X = torch.from_numpy(X)

    # Predict the tag
    output = model(X)
    _, predicted = torch.max(output, dim=1)
    tag = tags[predicted.item()]

    # Get the probability of the prediction
    probs = torch.softmax(output, dim=1)
    prob = probs[0][predicted.item()]

    if prob.item() > 0.75:
        # Fetch predefined responses for high-confidence predictions
        with open('intents.json', 'r') as f:
            intents = json.load(f)

        for intent in intents["intents"]:
            if tag == intent["tag"]:
                return random.choice(intent['responses']), tag
    else:
        # Fallback response for low-confidence predictions
        return "I'm not sure how to respond to that. Could you please rephrase?", None
