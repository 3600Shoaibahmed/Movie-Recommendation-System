import pandas as pd
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

def process_structured(df: pd.DataFrame):
    numeric_cols = ["age", "claim_amount"]
    if not all(col in df.columns for col in numeric_cols):
        raise ValueError("Missing required structured columns")
    features = df[numeric_cols].fillna(0)
    return scaler.fit_transform(features)
