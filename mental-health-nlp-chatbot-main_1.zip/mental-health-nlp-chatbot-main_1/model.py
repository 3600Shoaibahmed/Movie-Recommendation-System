import torch
import torch.nn as nn
from torch.utils.data import Dataset

class NeuralNet(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes, dropout_rate=0.5):
        """
        Neural Network for classification.
        Args:
            input_size (int): Size of input features.
            hidden_size (int): Number of neurons in hidden layers.
            num_classes (int): Number of output classes.
            dropout_rate (float): Dropout rate for regularization.
        """
        super(NeuralNet, self).__init__()
        self.l1 = nn.Linear(input_size, hidden_size)
        self.bn1 = nn.BatchNorm1d(hidden_size)
        self.l2 = nn.Linear(hidden_size, hidden_size)
        self.bn2 = nn.BatchNorm1d(hidden_size)
        self.l3 = nn.Linear(hidden_size, num_classes)
        
        self.dropout = nn.Dropout(dropout_rate)
        self.activation = nn.LeakyReLU(negative_slope=0.01)
        
        # Weight initialization
        self._initialize_weights()

    def _initialize_weights(self):
        """
        Applies Xavier initialization to all linear layers.
        """
        for layer in [self.l1, self.l2, self.l3]:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)

    def forward(self, x):
        """
        Forward pass of the neural network.
        """
        out = self.l1(x)
        out = self.bn1(out)
        out = self.activation(out)
        out = self.dropout(out)

        out = self.l2(out)
        out = self.bn2(out)
        out = self.activation(out)
        out = self.dropout(out)

        out = self.l3(out)  # No activation here (handled by loss function for classification)
        return out


class ChatDataset(Dataset):
    def __init__(self, X_train, y_train):
        """
        Custom dataset for the chatbot training data.
        Args:
            X_train (numpy array): Input features.
            y_train (numpy array): Target labels.
        """
        self.n_samples = len(X_train)
        self.x_data = X_train
        self.y_data = y_train
    
    def __getitem__(self, index):
        """
        Retrieves a single sample and its label.
        """
        return self.x_data[index], self.y_data[index]
    
    def __len__(self):
        """
        Returns the total number of samples.
        """
        return self.n_samples
