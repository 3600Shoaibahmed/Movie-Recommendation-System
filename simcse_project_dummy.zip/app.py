import streamlit as st
import random

st.title("SimCSE with Active Learning (Offline Demo)")

if "labeled" not in st.session_state:
    st.session_state.labeled = []
    st.session_state.unlabeled = [
        "John loved fishing and nature.",
        "Mary was a kind soul who helped many.",
        "David enjoyed teaching his students.",
        "Sarah was full of laughter.",
        "Michael inspired many with his words."
    ]

if st.button("Select Next Sample"):
    if st.session_state.unlabeled:
        query = random.choice(st.session_state.unlabeled)
        st.session_state.unlabeled.remove(query)
        st.session_state.labeled.append(query)
        st.success(f"Selected -> {query}")
    else:
        st.warning("No more samples left.")

st.subheader("Labeled Samples:")
st.write(st.session_state.labeled)

st.subheader("Remaining Unlabeled Samples:")
st.write(st.session_state.unlabeled)
