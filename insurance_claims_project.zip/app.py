import streamlit as st
import pandas as pd
import tensorflow as tf
from transformers import BertTokenizer, TFBertForSequenceClassification

# Load model
model = TFBertForSequenceClassification.from_pretrained("saved_model")
tokenizer = BertTokenizer.from_pretrained("saved_model")

st.title("Insurance Claim Classification")

uploaded_file = st.file_uploader("Upload Claims Excel", type=["xlsx"])

if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.write("Uploaded Data:", df.head())

    texts = df['claim'].astype(str).tolist()
    encodings = tokenizer(texts, truncation=True, padding=True, max_length=128, return_tensors="tf")

    outputs = model(encodings).logits
    predictions = tf.argmax(outputs, axis=1).numpy()

    df['Prediction'] = ["Fraud" if p == 1 else "Genuine" for p in predictions]
    st.write(df)

    # Option to download results
    df.to_excel("predicted_claims.xlsx", index=False)
    st.download_button("Download Results", data=open("predicted_claims.xlsx","rb"), file_name="predicted_claims.xlsx")
