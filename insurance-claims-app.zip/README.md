# Insurance Claims Prediction (Contrastive + Active Learning)

## Overview
Predicts insurance claim types (health, motor, life) using both **structured** (age, claim amount, etc.) 
and **unstructured** (claim text) data.

The system combines:
- Contrastive text encoder (Sentence-BERT)
- Fusion neural network (structured + text)

A Flask web app allows uploading claim files (CSV) and returns predictions.

---

## 📂 Structure
```
insurance-claims-app/
│── app/
│   ├── app.py
│   ├── templates/index.html
│   └── static/
│── src/
│   ├── fusion_model.py
│   ├── feature_engineering.py
│   └── utils.py
│── requirements.txt
│── README.md
```

⚠️ The `models/` folder (encoder + fusion weights) is **not included in GitHub**. 
Download separately (from Kaggle/personal storage) and place it inside the project root.

---

## 🚀 Usage

1. Clone repo
```bash
git clone https://github.com/<your-username>/insurance-claims-app.git
cd insurance-claims-app
```

2. Install requirements
```bash
pip install -r requirements.txt
```

3. Add `models/` folder manually:
```
models/
├── contrastive_encoder/
├── fusion_model.pth
└── fusion_meta.json
```

4. Run Flask app
```bash
python -m app.app
```

5. Open browser: `http://127.0.0.1:5000`
