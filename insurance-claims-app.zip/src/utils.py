import json, torch

def load_meta(path="models/fusion_meta.json"):
    with open(path) as f:
        return json.load(f)

def load_model(model_class, weights_path, meta):
    model = model_class(
        input_dim=meta["input_dim"],
        hidden_dim=meta["hidden_dim"],
        output_dim=meta["output_dim"]
    )
    model.load_state_dict(torch.load(weights_path))
    model.eval()
    return model
