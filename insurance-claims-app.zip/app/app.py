from flask import Flask, render_template, request
import pandas as pd
import torch, json
from sentence_transformers import SentenceTransformer
from src.fusion_model import FusionModel
from src.feature_engineering import process_structured

app = Flask(__name__)

# Load encoder locally
encoder = SentenceTransformer("models/contrastive_encoder")

# Load fusion model
with open("models/fusion_meta.json") as f:
    meta = json.load(f)

fusion_model = FusionModel(
    input_dim=meta["input_dim"],
    hidden_dim=meta["hidden_dim"],
    output_dim=meta["output_dim"]
)
fusion_model.load_state_dict(torch.load("models/fusion_model.pth"))
fusion_model.eval()

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    if request.method == "POST":
        file = request.files["file"]
        if file.filename.endswith(".csv"):
            df = pd.read_csv(file)
            structured_features = process_structured(df)
            text_embeddings = encoder.encode(df["claim_text"].tolist(), convert_to_tensor=True)
            inputs = torch.cat([torch.tensor(structured_features).float(), text_embeddings], dim=1)
            with torch.no_grad():
                outputs = fusion_model(inputs)
                prediction = outputs.argmax(dim=1).tolist()
        else:
            prediction = "Invalid file format. Upload CSV."
    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
