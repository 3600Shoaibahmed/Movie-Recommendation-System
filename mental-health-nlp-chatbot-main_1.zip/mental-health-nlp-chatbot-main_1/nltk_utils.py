import nltk
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.corpus import stopwords
import numpy as np
import re

# Download required NLTK data files
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')

stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))


def tokenize(sentence):
    """
    Tokenizes the input sentence into words.
    Args:
        sentence (str): The input sentence to tokenize.
    Returns:
        list: A list of words (tokens).
    """
    # Normalize by converting to lowercase and removing non-alphanumeric characters
    sentence = sentence.lower()
    sentence = re.sub(r'[^\w\s]', '', sentence)  # Remove punctuation
    tokens = nltk.word_tokenize(sentence)  # Tokenize into words
    return tokens


def process_word(word, use_stemming=True, use_lemmatization=False):
    """
    Processes a single word with stemming or lemmatization.
    Args:
        word (str): The word to process.
        use_stemming (bool): Whether to use stemming.
        use_lemmatization (bool): Whether to use lemmatization.
    Returns:
        str: The processed word.
    """
    if use_lemmatization:
        return lemmatizer.lemmatize(word.lower())
    elif use_stemming:
        return stemmer.stem(word.lower())
    else:
        return word.lower()


def preprocess_tokens(tokens, remove_stopwords=True, use_stemming=True, use_lemmatization=False):
    """
    Preprocesses a list of tokens by optionally removing stopwords, and applying stemming or lemmatization.
    Args:
        tokens (list): List of tokens (words).
        remove_stopwords (bool): Whether to remove stopwords.
        use_stemming (bool): Whether to apply stemming.
        use_lemmatization (bool): Whether to apply lemmatization.
    Returns:
        list: A list of preprocessed tokens.
    """
    processed_tokens = []
    for word in tokens:
        if remove_stopwords and word in stop_words:
            continue
        processed_tokens.append(process_word(word, use_stemming, use_lemmatization))
    return processed_tokens


def bag_of_words(tokenized_sentence, all_words):
    """
    Creates a bag-of-words representation for a tokenized sentence.
    Args:
        tokenized_sentence (list): Tokenized words from the input sentence.
        all_words (list): Vocabulary of all known words.
    Returns:
        numpy.ndarray: A bag-of-words array where each position represents the presence of a word in the sentence.
    """
    # Preprocess tokenized sentence
    tokenized_sentence = [word.lower() for word in tokenized_sentence]
    
    # Bag-of-words vector
    bag = np.zeros(len(all_words), dtype=np.float32)
    for idx, word in enumerate(all_words):
        if word in tokenized_sentence:
            bag[idx] = 1.0
    return bag
