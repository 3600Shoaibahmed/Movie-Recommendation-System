from flask import Flask, request, jsonify, session, render_template, redirect, url_for, flash
from chat import get_response, load_model  # Assuming this function processes and returns the bot's response
from flask_bcrypt import Bcrypt
from pymongo import MongoClient
from bson.objectid import ObjectId
import os
import sys
import speech_recognition as sr
import pyttsx3
import random
import string
import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your_secret_key")
bcrypt = Bcrypt(app)

# MongoDB Atlas connection setup
client = MongoClient("mongodb+srv://mohammed70saif:yLeGyFB025qMqqKM@cluster0.qoimh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")  # Replace with your MongoDB Atlas URI
db = client['chatbot_db']  # Database name
users_collection = db['users']  # Collection for users
chats_collection = db['chats']  # Collection for chats

class VoiceAssistant:
    def __init__(self):
        self.engine = pyttsx3.init()
        self.recognizer = sr.Recognizer()
        
        # Set voice to female if available
        voices = self.engine.getProperty('voices')
        for voice in voices:
            if 'female' in voice.name.lower():  # Check if the voice is female
                self.engine.setProperty('voice', voice.id)
                break
        else:
            # Fallback to default if no female voice is found
            self.engine.setProperty('voice', voices[0].id)

    def speak(self, text):
        self.engine.say(text)
        self.engine.runAndWait()

    def listen(self):
        with sr.Microphone() as source:
            print("Listening...")
            audio = self.recognizer.listen(source)
            try:
                text = self.recognizer.recognize_google(audio)
                print("You said:", text)
                return text
            except sr.UnknownValueError:
                print("Could not understand audio")
                return None
            except sr.RequestError:
                print("Could not request results from Google Speech Recognition service")
                return None

# Initialize Voice Assistant
voice_assistant = VoiceAssistant()

@app.route('/')
def home():
    session.clear()  # Clear the session on every visit to the home route
    return redirect(url_for('login'))  # Redirect to login page

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']  # Use email instead of username
        password = request.form['password']

        user = users_collection.find_one({'email': email})  # Query using email

        if user and bcrypt.check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])  # Store user ID in session
            return redirect(url_for('chat'))  # Redirect to chat page after login
        else:
            return render_template('login.html', error="Invalid email or password")

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']  # Change username to email
        password = request.form['password']
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        # Insert new user into MongoDB using email instead of username
        users_collection.insert_one({
            'email': email,
            'password': hashed_password
        })
        return redirect(url_for('login'))  # Redirect to login after registration

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))  # Redirect to login after logout

@app.route('/chat')
def chat():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in
    return render_template('chat.html')  # Render chat page

@app.route('/get', methods=['POST'])
def get_bot_response():
    user_input = request.json['message']
    user_id = session.get('user_id')  # Get current logged-in user's ID

    model, all_words, tags = load_model()
    bot_response, tag = get_response(user_input, model, all_words, tags)

    # Store the chat in MongoDB
    if user_id:
        chats_collection.insert_one({
            'user_id': ObjectId(user_id),
            'message': user_input,
            'response': bot_response
        })

    return jsonify({
        'response': bot_response,
        'fromVoice': request.json.get('fromVoice', False)
    })

@app.route('/history', methods=['GET'])
def get_chat_history():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'User not logged in'})

    # Fetch chat history from MongoDB
    chat_history = chats_collection.find({'user_id': ObjectId(user_id)})
    
    history = [{'message': chat['message'], 'response': chat['response'], 'timestamp': str(chat.get('timestamp', ''))} for chat in chat_history]
    return jsonify({'history': history})

# Function to send email
def send_email(to_email, subject, body):
    sender_email =  "animeodyssey.106@gmail.com"
    sender_password = "nrcs hzng hmlu ndbi"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.send_message(msg)
        print("Email sent successfully")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = users_collection.find_one({'email': email})

        if user:
            # Generate a reset token
            token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
            expiry_time = datetime.datetime.utcnow() + datetime.timedelta(hours=1)  # 1-hour expiry
            users_collection.update_one(
                {'_id': user['_id']},
                {'$set': {'reset_token': token, 'reset_token_expiry': expiry_time}}
            )

            # Send the reset email
            reset_link = url_for('reset_password', token=token, _external=True)
            email_body = (
                f"Dear user,\n\n"
                f"We received a request to reset the password for your account associated with the email address {email}.\n\n"
                f"To reset your password, please click the link below:\n\n"
                f"{reset_link}\n\n"
                f"If you did not request a password reset, please ignore this email. Your password will remain unchanged.\n\n"
                f"For your security, this link will expire in 1 hour.\n\n"
                f"If you have any questions or need further assistance, feel free to reach out to our support team.\n\n"
                f"Thank you for using our chatbot!\n\n"
                f"Best regards,\n"
                f"Phoenix Support Team\n"
                f"animeodyssey.106@gmail.com\n"
                f"[Your Website URL]"
            )
            send_email(email, 'Password Reset Request', email_body)

            flash('Password reset link has been sent to your email.', 'success')
            return redirect(url_for('login'))

        flash('Email not found', 'danger')
        return redirect(url_for('forgot_password'))

    return render_template('forgot_password.html')

@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = users_collection.find_one({'reset_token': token})

    if not user or user.get('reset_token_expiry') < datetime.datetime.utcnow():
        flash('Invalid or expired token', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        if new_password == confirm_password:
            hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')
            users_collection.update_one(
                {'_id': user['_id']},
                {'$set': {'password': hashed_password, 'reset_token': None, 'reset_token_expiry': None}}
            )
            flash('Password has been reset successfully. You can now log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Passwords do not match', 'danger')

    return render_template('reset_password.html')

if __name__ == '__main__':
    app.run(debug=True)
