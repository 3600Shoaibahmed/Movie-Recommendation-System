# app.py
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import tensorflow_hub as hub

def fit_clf(X, y):
    clf = LogisticRegression(max_iter=2000)
    clf.fit(X, y)
    return clf

def uncertainty_sampling(clf, X_pool, k):
    probs = clf.predict_proba(X_pool)[:, 1]
    uncertainty = np.abs(probs - 0.5)
    return np.argsort(uncertainty)[:k]

def active_learning(X_train, y_train, X_test, y_test, budget=200, batch_size=20, seed_size=10):
    n = X_train.shape[0]
    all_idx = np.arange(n)
    seed_idx = []
    for cls in np.unique(y_train):
        cls_idx = np.where(y_train == cls)[0]
        seed_idx.extend(np.random.choice(cls_idx, size=seed_size, replace=False))
    labeled = np.array(seed_idx)
    unlabeled = np.setdiff1d(all_idx, labeled)
    history = {"labels": [], "acc": []}
    clf = fit_clf(X_train[labeled], y_train[labeled])
    acc = accuracy_score(y_test, clf.predict(X_test))
    history["labels"].append(len(labeled))
    history["acc"].append(acc)
    while len(labeled) < seed_size*2 + budget:
        query_idx = uncertainty_sampling(clf, X_train[unlabeled], batch_size)
        new_idx = unlabeled[query_idx]
        labeled = np.concatenate([labeled, new_idx])
        unlabeled = np.setdiff1d(unlabeled, new_idx)
        clf = fit_clf(X_train[labeled], y_train[labeled])
        acc = accuracy_score(y_test, clf.predict(X_test))
        history["labels"].append(len(labeled))
        history["acc"].append(acc)
        if len(unlabeled) == 0:
            break
    return history

st.title("Contrastive Learning + Active Sampling (Google USE)")
st.write("⚡ Upload your insurance dataset or use demo data. Model: Universal Sentence Encoder (contrastive embeddings).")

uploaded_file = st.file_uploader("Upload CSV file with 'text' and 'label' columns", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    if "text" not in df.columns or "label" not in df.columns:
        st.error("CSV must have 'text' and 'label' columns")
        st.stop()
    X_text = df["text"].astype(str).values
    y = df["label"].values
    st.success(f"Loaded dataset with {len(X_text)} rows from uploaded file ✅")
else:
    from sklearn.datasets import fetch_20newsgroups
    categories = ["sci.med", "misc.forsale"]
    ds = fetch_20newsgroups(subset="all", categories=categories, remove=("headers","footers","quotes"))
    X_text, y = np.array(ds.data), np.array(ds.target)
    st.info("No file uploaded → using demo dataset (20 Newsgroups).")

X_train_text, X_test_text, y_train, y_test = train_test_split(X_text, y, test_size=0.2, random_state=42, stratify=y)

@st.cache_resource
def load_model():
    return hub.load("https://tfhub.dev/google/universal-sentence-encoder/4")

model = load_model()

st.write("Encoding text into embeddings... (this may take a minute)")
X_train = model(X_train_text).numpy()
X_test = model(X_test_text).numpy()

budget = st.slider("Labeling Budget", min_value=50, max_value=500, step=50, value=200)
batch_size = st.slider("Batch Size per Iteration", min_value=5, max_value=50, step=5, value=20)

history = active_learning(X_train, y_train, X_test, y_test, budget=budget, batch_size=batch_size)

clf_full = fit_clf(X_train, y_train)
full_acc = accuracy_score(y_test, clf_full.predict(X_test))

fig, ax = plt.subplots()
ax.plot(history["labels"], history["acc"], marker="o", label="Active (uncertainty)")
ax.axhline(full_acc, linestyle="--", color="red", label="Full Supervised")
ax.set_xlabel("# Labeled Samples")
ax.set_ylabel("Test Accuracy")
ax.set_title("Active Learning Curve")
ax.legend()
st.pyplot(fig)

st.subheader("Results")
st.write(pd.DataFrame({"#labels": history["labels"], "accuracy": history["acc"]}))
st.write(f"Full supervised accuracy = **{full_acc:.4f}**")
