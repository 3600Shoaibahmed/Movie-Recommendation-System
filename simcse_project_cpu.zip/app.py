import streamlit as st
import pandas as pd
import numpy as np
import os
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

st.title('SimCSE + Active Learning Demo (use your trained encoder)')
st.write('Place your trained encoder at saved_model/encoder.pt (or leave to use sample embeddings).')

uploaded = st.file_uploader('Upload CSV with text,label', type=['csv'])
if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    df = pd.read_csv('dataset/obituaries_sample.csv')

st.write('Dataset preview:')
st.dataframe(df.head())

if st.button('Run demo (uses sample embeddings)'):
    # create fake embeddings for demo
    texts = df['text'].astype(str).tolist()
    rng = np.random.RandomState(42)
    X = rng.randn(len(texts), 512)
    y = df['label'].values if 'label' in df.columns else np.zeros(len(texts))
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y if len(np.unique(y))>1 else None)
    clf = LogisticRegression(max_iter=2000)
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))
    st.write('Demo accuracy (random embeddings):', acc)
    fig, ax = plt.subplots()
    ax.plot([1,2,3],[0.5,0.6,acc], marker='o')
    ax.set_title('Placeholder learning curve')
    st.pyplot(fig)
